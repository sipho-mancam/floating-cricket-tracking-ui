import os
__CURRENT_DIRECTORY__ = os.path.dirname(__file__)

print(f"Current Directory: {__CURRENT_DIRECTORY__}")